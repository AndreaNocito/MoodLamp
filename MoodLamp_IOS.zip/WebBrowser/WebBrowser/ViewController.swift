//
//  ViewController.swift
//  WebBrowser
//
//  Created by Andrea Nocito on 10/06/17.
//  Copyright © 2017 Andrea Nocito. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
     //   let url = URL(string: "https://www.apple.com")
        let url = URL(string: "http://moodlamp.altervista.org/moodlamp.html")

        
        myWebView.loadRequest(URLRequest(url: url!))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

