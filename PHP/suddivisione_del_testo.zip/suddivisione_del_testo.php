<?php

$testo_ricevuto = "Inserisci la frase da analizzare.";
// parte in cui capisco se e' un testo o comandi
//	------------------
echo '<font="Avenir"> <p align="center">';
echo "<br> $testo_ricevuto <br>_____________________________<br> <br>";
//  ------------------
// analisi del periodo
$testo_ricevuto = array_filter(explode (".",$testo_ricevuto)); // estraggo i periodi e rimuovo elementi vuoti
for($i=0; $i<count($testo_ricevuto); $i++) {
	$testo[$i] = new periodo($testo_ricevuto[$i]);
	 $i++; echo "Periodo ".$i.": <br>"; $i--;
	$testo[$i]->print();
}

echo '</font> </p>';
?>



<?php
class periodo {
	var $frasi = array();

	function __construct() {
		$t = func_get_arg(0);
		$frasi = get_frasi($t);
		for($i=0; $i<count($frasi); $i++) {
			$this->frasi[$i]=array_filter(explode(" ",$frasi[$i]));
			$this->frasi[$i]=compatta_vettore($this->frasi[$i]);
		}	
	}
	function print() {
		for($i=0; $i<count($this->frasi); $i++) {
			 $i++; echo "Frase ".$i.": <br>"; $i--;
			for($j=0; $j<count($this->frasi[$i]); $j++) {
				echo $this->frasi[$i][$j]." ";
			}
			echo "<br>";
		}
	}
}
function get_frasi($t) {
	// devo restituire un array di frasi
	// elimino la punteggiatura: 
	$file = new SPLFileObject('./resources/punteggiatura.txt');
	$punt = array(); // punteggiatura
	foreach($file as $line) {
	    array_push($punt,trim($line)); // tolgo gli spazi
	}
	$frasi = explode_array($punt,$t);
	$file = new SPLFileObject('./resources/congiunzioni.txt');
	$cong = array(); // congiunzioni
	foreach($file as $line) {
	    $line = substr($line,0,-2); // tolgo gli spazi
	    $line = "*".$line."*";
	    array_push($cong, $line);
	}
	for($i=0; $i<count($frasi); $i++) {
		$frasi[$i]=strtolower($frasi[$i]);
		$frasi[$i] = "*".str_replace( " ", "* *", $frasi[$i])."*";

		$frasi[$i]=explode_array_($cong,$frasi[$i]);
		$frasi[$i] = str_replace( "*", "", $frasi[$i]);
	}
	$frasi1=array();
	for($i=0; $i<count($frasi); $i++) {
		for($j=0; $j<count($frasi[$i]); $j++) {
			array_push($frasi1,$frasi[$i][$j]);
		}
	}
	$frasi1=array_filter($frasi1);
	$i=0;
	foreach($frasi1 as $f) {  // elimino elementi vuoti
		if(strlen($f)>1) { // 1 per lo spazio iniziale che tolgo dopo
		$frasi[$i]=$f;
		$i++;
	}
	}
		return $frasi;
}
?>


<?php
function explode_array( $delimiters, $string )
{
	return explode( chr( 1 ), str_replace( $delimiters, chr( 1 ), $string ) );
}
function explode_array_( $delimiters, $string ) // non elimino i delimiters nel testo
{
	$frasi = array();
	$parole = explode(" ",$string);
	$num_frase=0;
	$frasi[0]="";
	for($i=0; $i<count($parole); $i++) {
		if(in_array($parole[$i],$delimiters)) {
			if(strlen($frasi[$num_frase])>0) {
			$num_frase++;
			$frasi[$num_frase]="";
			$frasi[$num_frase]=substr($frasi[$num_frase],1);
			}
		}
			$frasi[$num_frase].=" ".$parole[$i];
	}
	return $frasi;
}
function compatta_vettore($vettore) {
	$v = array();
	reset($vettore);
	for($i=0; $i<count($vettore);$i++) {
		$v[$i]=current($vettore);
		next($vettore);
	}
	return $v;
	
}

?>    