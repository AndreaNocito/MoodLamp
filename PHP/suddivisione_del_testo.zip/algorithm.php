<?php

//scrivi("./contents/prova.txt",$page);
$testo_ricevuto = "Inserisci qui la frase (se stai leggendo da editor, altrimenti apri il file php e modifica la stringa)";
// parte in cui capisco se e' un testo o comandi
//	------------------
echo '<font="Avenir"> <p align="center">';
echo "<br> $testo_ricevuto <br>_____________________________<br> <br>";
//  ------------------
// analisi del periodo
$testo_ricevuto = array_filter(explode (".",$testo_ricevuto)); // estraggo i periodi e rimuovo elementi vuoti
	// print_r($testo_ricevuto); echo "<br>";
for($i=0; $i<count($testo_ricevuto); $i++) {
	$testo[$i] = new periodo($testo_ricevuto[$i]);
	 $i++; echo "Periodo ".$i.": <br>"; $i--;
	$testo[$i]->print();
}

echo '</font> </p>';
?>



<?php
class periodo {
	var $frasi = array();

	function __construct() {
		$t = func_get_arg(0);
		$frasi = $this->get_frasi($t);
		for($i=0; $i<count($frasi); $i++) {
			$this->frasi[$i]=array_filter(explode(" ",$frasi[$i]));
			$this->frasi[$i]= $this->compatta_vettore($this->frasi[$i]);
			//print_r($this->frasi[$i]);
			//echo "<br>";
		}	
	}
	function print() {
		for($i=0; $i<count($this->frasi); $i++) {
			 $i++; echo "Frase ".$i.": <br>"; $i--;
			for($j=0; $j<count($this->frasi[$i]); $j++) {
				if($j%2==0) { echo "<b>";}
				echo $this->frasi[$i][$j]." ";
				if($j%2==0) { echo "</b>";}
			}
			echo "<br>";
		}
	}
	function get_frasi($t) {
		// devo restituire un array di frasi
		// elimino la punteggiatura: 
		$file = new SPLFileObject('./resources/punteggiatura.txt');
		$punt = array(); // punteggiatura
		foreach($file as $line) {
	    // echo $line."<br>";
	    array_push($punt,trim($line)); // tolgo gli spazi
		}
		//	echo "<br> ---__--- <br>";
		//	print_r($punt);
		//	echo "<br> ---__--- <br>";
		$frasi = array_filter( $this->explodeX($punt,$t));
		//	print_r($frasi);
		// echo "<br><br>__________ <br> punteggiatura OK <br>__________<br><br>";

		// $file = fopen("./resources/congiunzioni.txt", "r");
		$file = new SPLFileObject('./resources/congiunzioni.txt');
		$cong = array(); // congiunzioni
		foreach($file as $line) {
	    //echo "!".$line."!<br>";
	    $line = substr($line,0,-2); // tolgo gli spazi
	    $line = "*".$line."*";
	    array_push($cong, $line);
		}
		//	echo "<br> ---__--- <br>";
		//	print_r($cong);
		//	echo "<br> ---__--- <br>";
		for($i=0; $i<count($frasi); $i++) {
			$frasi[$i]=strtolower($frasi[$i]);
			$frasi[$i] = "*".str_replace( " ", "* *", $frasi[$i])."*";

			$frasi[$i]= $this->explode_X($cong,$frasi[$i]);
			$frasi[$i] = str_replace( "*", "", $frasi[$i]);
		//echo "<br>";
		}
		//	print_r($frasi);
		//	echo " <br> <br>";


		$frasi1=array();
		for($i=0; $i<count($frasi); $i++) {
			for($j=0; $j<count($frasi[$i]); $j++) {
				if(!is_array(!$frasi[$i][$j]))
					array_push($frasi1,$frasi[$i][$j]);
			
		}
			echo "<br>";
		}
		//print_r($frasi1);
		$frasi1=array_filter($frasi1);
		$i=0;
		$frasi[$i]=null;
		foreach($frasi1 as $f) {  // elimino elementi vuoti
			if(strlen($f)>1) { // 1 per lo spazio iniziale che tolgo dopo
				//echo "!$f!-".strlen($f)."<br>";
				$frasi[$i]=$f;
				$i++;
			}
		}
		//	print_r($frasi);
		//	echo "<br><br> -!-!-!-!-!-<br><br>";

		return $frasi;
	}
	function explodeX( $delimiters, $string ) {

	return explode( chr( 1 ), str_replace( $delimiters, chr( 1 ), $string ) );
	}
	function explode_X( $delimiters, $string ) {
	$frasi = array();
	$parole = explode(" ",$string);
	$num_frase=0;
	$frasi[0]="";
	//print_r($string);
	for($i=0; $i<count($parole); $i++) {
		if(in_array($parole[$i],$delimiters)) {
			if(strlen($frasi[$num_frase])>0) {
			$num_frase++;
			$frasi[$num_frase]="";
			$frasi[$num_frase]=substr($frasi[$num_frase],1);
			}
		}
			$frasi[$num_frase].=" ".$parole[$i];
	}
	//echo " return: ";
	//print_r($frasi);
	//echo "<br>";
	return $frasi;
	}
	function compatta_vettore($vettore) {
		$v = array();
		if($vettore==null) {
			return null;
		}
		else {
			reset($vettore);
			for($i=0; $i<count($vettore);$i++) {
				$v[$i]=current($vettore);
				next($vettore);
			}
			return $v;	
		}
	}
}
function scrivi($f,$t) {
	$file = fopen($f, "w") or die ("File non trovato");
	fwrite($file,$t);
	fclose($file);
}
?>    